import Login from "./Components/Login";
import Register from "./Components/Signup";
import PrivateRoute from "./Components/privateroute";
import { Routes, Route } from "react-router-dom";
import Patient from "./Components/Patient/Patient";
import Doctor from "./Components/Doctors";
import ReduxLearning from "./Components/ReduxLearning";
import { App } from "antd";
import Speechrecognition from "./Components/Speech";
import "./App.css";

const Apps = () => {
  return (
    <div className="App">
      {/* <ReduxLearning /> */}
      {/* <Home/> */}
      <Routes>
        <Route
          path="/"
          element={
            <App message={{ maxCount: 1 }}>
              <Login />
            </App>
          }
        />
        <Route path="/signup" element={<Register />} />
        <Route element={<PrivateRoute />}>
          <Route path="doctor/*" element={<Doctor />}></Route>
          <Route path="patient/*" element={<Patient />}></Route>
        </Route>
      </Routes>
      {/* <Speechrecognition/> */}
    </div>
  );
};
export default Apps;
